import java.math.BigInteger;
import java.net.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class SigningClientTCP{
    static InetAddress aHost;
    static int serverPort;
    static Socket clientSocket = null;
    static String replyString = "";


    public static void main(String args[]) throws NoSuchAlgorithmException {
        System.out.println("The client is running.\n");

        // ----------------------- Generate the key -----------------------
        // from https://github.com/CMU-Heinz-95702/Project-2-Client-Server

        // Each public and private key consists of an exponent and a modulus
        BigInteger n; // n is the modulus for both the private and public keys
        BigInteger e; // e is the exponent of the public key
        BigInteger d; // d is the exponent of the private key

        Random rnd = new Random();

        // Step 1: Generate two large random primes.
        // We use 400 bits here, but best practice for security is 2048 bits.
        // Change 400 to 2048, recompile, and run the program again and you will
        // notice it takes much longer to do the math with that many bits.
        BigInteger p = new BigInteger(400, 100, rnd);
        BigInteger q = new BigInteger(400, 100, rnd);

        // Step 2: Compute n by the equation n = p * q.
        n = p.multiply(q);

        // Step 3: Compute phi(n) = (p-1) * (q-1)
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));

        // Step 4: Select a small odd integer e that is relatively prime to phi(n).
        // By convention the prime 65537 is used as the public exponent.
        e = new BigInteger("65537");

        // Step 5: Compute d as the multiplicative inverse of e modulo phi(n).
        d = e.modInverse(phi);

        System.out.println("RSA public key: (" + e + "," + n + ")");  // Step 6: (e,n) is the RSA public key
        System.out.println("RSA private key: (" + d + "," + n + ")\n");  // Step 7: (d,n) is the RSA private key


        // ----------------------- Generate the ID -----------------------
        // from https://github.com/CMU-Heinz-95702/Project-2-Client-Server

        String rawPublicKey = String.valueOf(e) + String.valueOf(n);

        MessageDigest md  = MessageDigest.getInstance("SHA-256");
        md.update(rawPublicKey.getBytes());

        byte[] digest = md.digest();

        BigInteger biID = new BigInteger(Arrays.copyOfRange(digest, digest.length-20, digest.length));
        String ID = biID.toString() + " ";
        // source: https://stackoverflow.com/questions/18367539/slicing-byte-arrays-in-java


        // ----------------------- Connect socket and create packet to send -----------------------
        try {
            // set to localhost to host on local machine and set port
            aHost = InetAddress.getByName("localhost");
            serverPort = 6789;

            // input server port to use
            System.out.print("Input a server side port number: ");
            Scanner readline = new Scanner(System.in);
            serverPort = readline.nextInt();

            clientSocket = new Socket("localhost", serverPort);


            String operation = "";
            String value = "";

            String packet = "";

            while (true) {
                System.out.println("\n1. Add a value to your sum.\n" +
                        "2. Subtract a value from your sum.\n" +
                        "3. Get your sum.\n" +
                        "4. Exit client");

                int in = readline.nextInt();

                if(in == 1){
                    operation = "1 ";
                    System.out.println("Enter value to add: ");
                    value = String.valueOf(readline.nextInt()) + " ";
                }
                else if(in == 2){
                    operation = "2 ";
                    System.out.println("Enter value to subtract: ");
                    value = String.valueOf(readline.nextInt() + " ");
                }
                else if(in == 3){
                    operation = "3 ";
                    value = "| ";
                }
                else if(in == 4){
                    System.out.println("Client side quitting. The remote variable server is still running."); // send reply if not halt
                    break;
                }

                packet += operation + ID + value + e + " " + n;

                // compute the digest with SHA-256
                byte[] bytesOfMessage = packet.getBytes("UTF-8");
                MessageDigest md2 = MessageDigest.getInstance("SHA-256");
                byte[] bigDigest = md2.digest(bytesOfMessage);
                byte[] messageDigest = new byte[bigDigest.length+1];

                // we only want two bytes of the hash for ShortMessageSign
                // we add a 0 byte as the most significant byte to keep
                // the value to be signed non-negative.
                messageDigest[0] = 0;   // most significant set to 0
                for(int i = 0; i < bigDigest.length; i++){
                    messageDigest[i+1] = bigDigest[i];
                }

                // From the digest, create a BigInteger
                BigInteger m = new BigInteger(messageDigest);

                // encrypt the digest with the private key
                BigInteger c = m.modPow(d, n);

                // send the packet
                packet += " " + c.toString();
                System.out.println("The result is: " + communicate(packet));

                packet = "";
            }

            // catch potential exceptions
        }catch (IOException ex) {
            System.out.println("IO Exception:" + ex.getMessage());
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException ex) {
                // ignore exception on close
            }
        }
    }

    // ----------------------- Proxy style communication code -----------------------
    public static String communicate(String in) throws IOException {
        BufferedReader read = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

        out.println(in);
        out.flush();

        String replyString = read.readLine();

        return replyString;
    }
}