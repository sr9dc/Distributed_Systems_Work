import java.math.BigInteger;
import java.net.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import java.util.*;

public class VerifyingServerTCP{
    private static TreeMap<String, Integer> tree_map = new TreeMap<>();

    static String instructions = "1. Add a value to your sum.\n" +
            "2. Subtract a value from your sum.\n" +
            "3. Get your sum.\n" +
            "4. Exit client";

    public static void main(String args[]){
        System.out.println("The server is running."); // lab instructions


        Socket clientSocket = null;
        byte[] buffer = new byte[1000];  // set up packet buffer for client message
        try{
            // set up ports
            System.out.print("Input a server port number to listen on: ");
            Scanner readline = new Scanner(System.in);
            int serverPort = readline.nextInt(); // convert to int

            ServerSocket listenSocket = new ServerSocket(serverPort);


            String id;
            int value;
            String e;
            String n;

            while(true){ // loop to continue until 'halt!' is sent
                clientSocket = listenSocket.accept();

                Scanner in;
                in = new Scanner(clientSocket.getInputStream());

                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

                // operation request and reply
                while(in.hasNext()){
                    String requestString = in.nextLine();

                    String[] arrRequestString = requestString.split(" ");

                    // check id verification
                    boolean idSignatureCheck = idSignatureCheck(arrRequestString[0], arrRequestString[1], arrRequestString[2],
                            arrRequestString[3],arrRequestString[4], arrRequestString[5]);

                    if(!idSignatureCheck){
                        out.println("Error in request.");
                        out.flush();
                    }

                    else{
                        id = arrRequestString[1];

                        if(!tree_map.containsKey(id)){
                            if(arrRequestString[0].equals("1")){
                                value = Integer.valueOf(arrRequestString[2]);
                                tree_map.put(id, value);
                            }
                            else if(arrRequestString[0].equals("2")){
                                value = -1*Integer.valueOf(arrRequestString[2]);
                                tree_map.put(id, value);
                            }
                            else{
                                tree_map.put(id, 0);
                            }
                        }
                        else{
                            if(arrRequestString[0].equals("1")){
                                value = Integer.valueOf(arrRequestString[2]);
                                tree_map.replace(id, tree_map.get(id)+value);
                            }
                            else if(arrRequestString[0].equals("2")){
                                value = Integer.valueOf(arrRequestString[2]);
                                tree_map.replace(id, tree_map.get(id)-value);
                            }
                        }

                        System.out.println("\nVisitor Public Key: (" + arrRequestString[3] + "," + arrRequestString[4] + ")");
                        System.out.println("VisitorID: " + arrRequestString[1]);
                        System.out.println("ID and Signature Verified: Yes");
                        System.out.println("Operation #: " + arrRequestString[0]);
                        System.out.println("Return Variable " + String.valueOf(tree_map.get(id)));

                        out.println(String.valueOf(tree_map.get(id)));
                        out.flush();
                    }
                }
            }
            // catch potential exceptions
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
            // If quitting (typically by you sending quit signal) clean up sockets
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }

//    operation + ID + value + e + " " + n;
    public static boolean idSignatureCheck(String operation, String id, String value, String e, String n, String signature) throws IOException, NoSuchAlgorithmException {

        // ----------------- Check ID -----------------
        String rawPublicKey = e + n;

        MessageDigest md  = MessageDigest.getInstance("SHA-256");
        md.update(rawPublicKey.getBytes());

        byte[] digest = md.digest();

        BigInteger idCheckBigInt = new BigInteger(Arrays.copyOfRange(digest, digest.length-20, digest.length));
        String idCheck = idCheckBigInt.toString();


        // ----------------- Check Message -----------------

        // Take the encrypted string and make it a big integer
        BigInteger encryptedHash = new BigInteger(signature);
        BigInteger decryptedHash = encryptedHash.modPow(new BigInteger(e), new BigInteger(n));

        // Get the bytes from messageToCheck
        String messageToCheck = operation + " " + id + " " + value + " " + e + " " + n;

        MessageDigest md2 = MessageDigest.getInstance("SHA-256");

        byte[] messageToCheckDigest = md2.digest(messageToCheck.getBytes("UTF-8"));

        // messageToCheckDigest is a full SHA-256 digest
        // take two bytes from SHA-256 and add a zero byte
        byte[] extraByte = new byte[messageToCheckDigest.length+1];

        extraByte[0] = 0;   // most significant set to 0
        for(int i = 1; i < extraByte.length; i++){
            extraByte[i] = messageToCheckDigest[i-1];
        }

        // Make it a big int
        BigInteger bigIntegerToCheck = new BigInteger(extraByte);

        // inform the client on how the two compare
        if((bigIntegerToCheck.compareTo(decryptedHash) == 0) && (idCheck.equals(id))) {
            return true;
        }
        else{
            return false;
        }
    }
}